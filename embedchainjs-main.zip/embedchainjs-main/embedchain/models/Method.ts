export type Method = 'init' | 'query' | 'add' | 'add_local';
