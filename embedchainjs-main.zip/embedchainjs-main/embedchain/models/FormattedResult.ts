import type { Document } from 'langchain/document';

export type FormattedResult = [Document, number | null];
