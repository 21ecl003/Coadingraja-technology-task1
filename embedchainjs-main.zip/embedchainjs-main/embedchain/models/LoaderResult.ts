import type { Metadata } from './Metadata';

export type LoaderResult = { content: any; metaData: Metadata }[];
