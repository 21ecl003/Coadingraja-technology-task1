export type Metadata = {
  url: string;
};
