type Question = string;
type Answer = string;

export type QnaPair = [Question, Answer];
