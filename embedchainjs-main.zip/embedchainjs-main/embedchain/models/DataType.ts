export type DataType = 'pdf_file' | 'web_page' | 'qna_pair';
